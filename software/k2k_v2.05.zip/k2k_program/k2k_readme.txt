K2K program [help file]

TABLE OF CONTENT:

1. BASIC DESCRIPTION
2. HOW TO USE THE PROGRAM
3. ADVANCED INFO
4. CONTACT

=====================
1. BASIC DESCRIPTION
=====================

K2K program runs the test based on the paper by Evzen Kocenda, 2001, "An Alternative to the BDS Test: Integration Across the Correlation Integral", [K2K test], Econometric Reviews, 20, 3, 337-351 and the paper by Evzen Kocenda and Lubos Briatka, 2004, "Advancing the iid Test Based on Integration across the Correlation Integral: Ranges, Competition, and Power", CERGE-EI Working Paper No. 235.

The K2K.EXE program calculate values of the correlation integral Cm for 41 values of proximity parameter epsilon. You have four basic choices for range of epsilons <0.60; 1.90>, <0.25; 1.00>, <0.50; 1.50> or <0.25; 2.00> of standard deviation. This is done at nine embedding dimensions m = 2,...,10. The interval <0.60; 1.90> is set as a template option.

The program computes the values of slope coefficients beta(m), automatically suggests the optimal set of critical values based on the sample size, compares the computed slope with critical values and note the significance.

The program consist of two parts:
1) K2K.EXE - graphical user interface
2) K2K_ENGINE.EXE - computation modul

==========================
2. HOW TO USE THE PROGRAM
==========================

1) run K2K.EXE (be sure that K2K.EXE and K2K_ENGINE.EXE are in the same directory)
2) click [...] button and browse for the data filename
3) choose a range of epsilons
4) choose maximal embedding dimension m
5) in case of data samples with size other than 500, 1000 or 2500 observations, you can change suggested set of critical values
5) click [Run the test] button and wait for calculation to be finished
6) if you want to transfer the results into other program just click the right mouse button and choose [Copy results into Clipboard]
7) if you want you can change the parameters and run the test again

The program can process up to 10000 observations. If the data file has more than 10000 data entries, only the first 10000 are read. An observation between 0 and 1 must be preceeded by a 0 and negative numbers must have the negative sign next to the leading digit. The input data must be separated by EOLN (end of line) character. The suggested idea is to have data in a single column in an ASCII file in one of the following formats:
240379      integer
-24.0379    real
2.40e+379   floating point
No other characters can be in the data file. However, program will accept also a decimal comma separator instead of decimal point separator. A blank lines or lines that cannot be understood will be skipped. The number of skipped observations is indicated in the program. The last entry must be followed by the EOF (end of file) character. The range of values is -1.7e-308 to 1.7e+308 (64-bits, double).

There is a data diagnostic table built in, which gives you a description of the data: number of observations, mean, standard deviation, spread and the standard deviation divided by the spread. As a test for normality of the input data values of kurtosis, skewnes, and Bera-Jarque normality tests are provided as well. For an even more detailed view of the series tested, one can use the histogram button: a new pop-up window opens and a histogram (up to 50 dividing bins) is plotted.

Although, the computers at the present time are very fast, the computation on the slower computers with large number of observations can take several minutes. Be patient.

=================
3. ADVANCED INFO
=================

The program and the engine comunicate together throught the files "input.tmp" and "output.tmp", please do not manipulate these files during the calculations. The program will autamatically erase these files from your disk when all computation will be succesfully done and program closed. If you close program during the computation, then the resident modul K2K_ENGINE.EXE could remain in the memory. If you want to remove it just open TASK MANAGER and close the appropriate process.

Advanced users and those interested in doing simulations may want to use K2K engine on their own. In that case just run K2K_ENGINE.EXE in dos prompt. The basic menu will appear.

USAGE: K2K_ENGINE.EXE [filename] [m] [eps_low] [eps_high] [subint] [write_0/1]
filename  ...  contains the time series in a single column
m         ...  maximum embedding dimension
eps_low   ...  lowest fraction of the SD
eps_high  ...  highest fraction of the SD
subint    ...  number of subintervals [optional_1]
cm_limit  ...  calculation limit for correlation integral [optional_1]
write_0/1 ...  type 1 if you want to write output into file [optional_2]

EXAMPLES:
 K2K_ENGINE.EXE input.txt 6 0.25 1.00
 => run the test for residuals in the file "input.txt" up to the embedding dimension 6

 K2K_ENGINE.EXE input.txt 6 0.50 1.50 40 50
 => run the test for residuals in the file "input.txt" up to the embedding dimension 6 for different value of range of epsilon, the values [subint=40] and [cm_limit=50] are optional

 K2K_ENGINE.EXE input.txt 6 0.25 2.00 40 50 1
 => run the test for residuals in the file "input.txt" for the embedding dimension 6 and save the result into the file "output.tmp"

The K2K program requires Windows 98/2000/NT/XP environment. The program is user friendly and should be self explanatory. Feel free to use the program (with appropriate citations) and to distribute it. No warranty of any kind is expressed or implied. 

Please send your comments or bugs you may find in the program to the author. Thanks you.

===========
4. CONTACT
===========

Lubos Briatka
CERGE-EI
P.O. Box 882
Politickych veznu 7
111 21 Praha 1
Czech Republic

e-mail: lubos.briatka@cerge-ei.cz
